# About Page

This is a simple responsive About page with animations, built using HTML, CSS, and AOS for scroll animations.