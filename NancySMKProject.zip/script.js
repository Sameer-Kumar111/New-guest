window.addEventListener("load", () => {
    document.querySelector(".loader").style.display = "none";
});
const navToggle = document.getElementById("nav-toggle");
const navMenu = document.getElementById("nav-menu");
navToggle.addEventListener("click", () => {
    navMenu.classList.toggle("active");
});
const typewriter = document.querySelector(".typewriter");
const text = "Welcome to Nancy SMK Ltd!";
let index = 0;
function type() {
    if (index < text.length) {
        typewriter.textContent += text.charAt(index);
        index++;
        setTimeout(type, 100);
    }
}
type();
